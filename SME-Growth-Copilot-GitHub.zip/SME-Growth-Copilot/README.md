# SME Growth Copilot 🚀

## AI-Powered Management Analytics & Decision Support for SMEs

**Created and developed by Rithik Bhattacharjee**

SME Growth Copilot is an AI-assisted management analytics project designed to help small and medium-sized businesses convert operational data into actionable management insights.

### Business questions
- Which marketing channels perform efficiently?
- Where is acquisition spending concentrated?
- What is CAC and conversion rate?
- How are revenue and customer acquisition changing?
- Where could management investigate budget reallocation?

### Workflow

Business Data → Data Cleaning → KPI Calculation → Analytics → Dashboard → AI-Assisted Interpretation → Management Recommendations

### Core KPIs
Revenue, Revenue Growth, Marketing Spend, Leads, Conversion Rate, CPL, CAC, AOV, ROMI and Repeat Customer Rate.

### Technology
Python, Pandas, Excel, Power BI, SQL, Generative AI and GitHub.

### Repository
- `data/raw/` — synthetic source data
- `data/processed/` — calculated datasets
- `analysis/` — Python analysis scripts
- `dashboard/` — dashboard plan
- `docs/` — methodology and data dictionary
- `reports/` — project report

### Data disclaimer
The included data is synthetic demonstration data and does not represent an actual company's performance.

### Creator
**Rithik Bhattacharjee**  
Management Analytics | Business Intelligence | AI

This project was conceptualized and developed by Rithik Bhattacharjee as an applied management analytics and AI portfolio project.

### Status
Prototype / Portfolio Project
